package com.example.myjfxp;

public class SchDefenseControl {
}
